
  # Design VeaHome Mobile UI

  This is a code bundle for Design VeaHome Mobile UI. The original project is available at https://www.figma.com/design/Tqrhnvpm3WlcxSABCuXAdu/Design-VeaHome-Mobile-UI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  